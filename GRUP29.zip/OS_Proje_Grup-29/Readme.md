# B191210065 - SONGÜL BAYER - 1B - songul.bayer@ogr.sakarya.edu.tr
# B191210062 - ZEHRA BEGÜM AKTOLGA - 1B - zehra.aktolga@ogr.sakarya.edu.tr
# B191210014 - CEYDA PEHLİVANOĞLU - 1B - ceyda.pehlivanoglu@ogr.sakarya.edu.tr
# B191210074 - NAZLI NUR ESMERAY - 1B - nazli.esmeray@ogr.sakarya.edu.tr
# B191210098 - AYŞEGÜL ÖZSOY - 1B - aysegul.ozsoy6@ogr.sakarya.edu.tr

# gcc -std=c99 -Wall -o kabuk main.c yazılarak derlenir
# Batch modu için derledikten sonra "./kabuk dosyaismi" yazılır.
# "/.kabuk" şeklinde çalıştırılınca interaktif şekilde çalışır.
# kabuk.c dosyası ile yazmaya başladık. Daha sonra başlık dosyalarına ayırdığımızda çok fazla hata olduğu için ayırmamaya karar verdik.
# Programı yazarken ders notlarından ve githubdan yararlandık.

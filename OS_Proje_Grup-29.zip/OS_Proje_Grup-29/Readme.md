# G181210081 - BÜŞRA AKAY - 2B - busra.akay@ogr.sakarya.edu.tr
# G181210042 - AHMET SEFA GÜVER - 2B - ahmet.guver@ogr.sakarya.edu.tr
# G181210063 - ABDULLAH ELVATANİ - 2B - abdullah.elvatani@ogr.sakarya.edu.tr
# G181210054 - MERVE KEÇELİ - 1B - merve.keceli@ogr.sakarya.edu.tr
# B181210015 - HİLAL YILDIZ - 1B - hilal.yildiz6@ogr.sakarya.edu.tr

# gcc -std=c99 -Wall -o kabuk main.c yazılarak derlenir
# Batch modu için derledikten sonra "./kabuk dosyaismi" yazılır.
# "/.kabuk" şeklinde çalıştırılınca interaktif şekilde çalışır.
# kabuk.c dosyası ile yazmaya başladık. Daha sonra başlık dosyalarına ayırdığımızda çok fazla hata olduğu için ayırmamaya karar verdik.

